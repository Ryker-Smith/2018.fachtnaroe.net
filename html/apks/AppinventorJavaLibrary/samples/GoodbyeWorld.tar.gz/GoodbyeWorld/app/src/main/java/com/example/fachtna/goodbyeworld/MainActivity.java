package com.example.fachtna.goodbyeworld;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        change();
    }

    void change() {
        final TextView mainMessage = (TextView) findViewById(R.id.mainMessage);
        mainMessage.setText("Goodbye");

        Button buttonMessage = (Button) findViewById(R.id.buttonMessage);
        buttonMessage.setText("Press for stuff");
        buttonMessage.setX(0);
        buttonMessage.setY(100);

        buttonMessage.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View v) {

                mainMessage.setText("And good luck");
                finishAndRemoveTask();
            }
        });
    }
}


