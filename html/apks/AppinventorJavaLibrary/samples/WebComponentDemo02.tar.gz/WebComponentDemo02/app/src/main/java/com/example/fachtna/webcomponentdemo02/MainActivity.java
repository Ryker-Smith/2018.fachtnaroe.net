package com.example.fachtna.webcomponentdemo02;

import android.widget.TextView;

import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.TextBox;
import com.google.appinventor.components.runtime.VerticalScrollArrangement;
import com.google.appinventor.components.runtime.Web;

public class MainActivity extends Form implements HandlesEventDispatching
{
    private Button connectionButton;
    private Label sendLabel, responseLabel;
    private Web webComponent;
    private VerticalScrollArrangement screenContainer;
    private HorizontalArrangement topLine, nextLine;
    private TextBox inputBox, outputBox;
    private String remoteHost = "fachtnaroe.net";//"192.168.7.25";//"fachtnaroe.net";
//    private TextView myHW;

    public MainActivity() {

    }

    protected void $define() {

        screenContainer= new VerticalScrollArrangement(this);
//        myHW = new TextView(screenContainer);
//        myHW =  findViewById(R.id.test2);

        screenContainer.WidthPercent(100);
        screenContainer.HeightPercent(100);

        topLine = new HorizontalArrangement(screenContainer);
        topLine.WidthPercent(100);
        topLine.Height(100);

        sendLabel = new Label(topLine);
        sendLabel.Text("Send: ");

        inputBox = new TextBox(topLine);
        inputBox.WidthPercent(100);
        inputBox.Text("https://" + remoteHost + "/generic?cmd=ver");
//----
        nextLine = new HorizontalArrangement(screenContainer);
        nextLine.WidthPercent(100);
        nextLine.Height(100);

        responseLabel = new Label(nextLine);
        responseLabel.Text("Receive: ");

        outputBox = new TextBox(nextLine);
        outputBox.WidthPercent(100);
        outputBox.Text("Waiting");

        connectionButton = new Button(screenContainer);
        connectionButton.Text("Connect");
        connectionButton.BackgroundColor(COLOR_LTGRAY);
        connectionButton.WidthPercent(50);

        connectionButton.TextAlignment(Component.ALIGNMENT_CENTER);

        webComponent = new Web(screenContainer);

        EventDispatcher.registerEventForDelegation( this, "connectButton", "Click" );
        EventDispatcher.registerEventForDelegation( this, "webComponent", "GotText" );
    }

    public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params)
    {
//        myHW.setText("hkjhkjhkj");
        if (component.equals(connectionButton) && eventName.equals("Click"))
        {
            connectionButtonClick();
            return true;
        }
        else if (component.equals(webComponent) && eventName.equals("GotText"))
        {
            String result = (String) params[3];
            youveGotText(result);
            return true;
        }
        else {
            responseLabel.Text("Not matched");
        }

        // here is where you'd check for other events of your app...
        return false;
    }

    public void connectionButtonClick() {
        String targetURL;
        connectionButton.Text("Pressed, getting remote version number: ");
        targetURL=inputBox.Text();
        webComponent.Url(targetURL);
        webComponent.Get();
    }

    public void youveGotText(String result) {
        connectionButton.Text("Got data: ");
        outputBox.Text(result);
    }

}
