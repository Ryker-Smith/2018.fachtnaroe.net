// Copyright 2010 Google Inc. All Rights Reserved.

package com.google.devtools.simple.runtime.components.android;

import com.google.devtools.simple.common.ComponentCategory;
import com.google.devtools.simple.common.PropertyCategory;
import com.google.devtools.simple.common.YaVersion;
import com.google.devtools.simple.runtime.annotations.DesignerComponent;
import com.google.devtools.simple.runtime.annotations.DesignerProperty;
import com.google.devtools.simple.runtime.annotations.SimpleEvent;
import com.google.devtools.simple.runtime.annotations.SimpleFunction;
import com.google.devtools.simple.runtime.annotations.SimpleObject;
import com.google.devtools.simple.runtime.annotations.SimpleProperty;
import com.google.devtools.simple.runtime.events.EventDispatcher;

import android.os.Handler;

/**
 * A component that provides a high-level interface to a touch sensor on a LEGO
 * MINDSTORMS NXT robot.
 *
 */
@DesignerComponent(version = YaVersion.NXT_TOUCHSENSOR_COMPONENT_VERSION,
    description = "A component that provides a high-level interface to a touch sensor on a " +
    "LEGO MINDSTORMS NXT robot.",
    category = ComponentCategory.LEGOMINDSTORMS,
    nonVisible = true,
    iconName = "images/legoMindstormsNxt.png")
@SimpleObject
public class NxtTouchSensor extends LegoMindstormsNxtSensor implements Deleteable {

  private enum State { UNKNOWN, PRESSED, RELEASED }
  private static final String DEFAULT_SENSOR_PORT = "1";

  private Handler handler;
  private State previousState;
  private final Runnable sensorReader;
  private boolean pressedEventEnabled;
  private boolean releasedEventEnabled;

  /**
   * Creates a new NxtTouchSensor component.
   */
  public NxtTouchSensor(ComponentContainer container) {
    super(container, "NxtTouchSensor");
    handler = new Handler();
    previousState = State.UNKNOWN;
    sensorReader = new Runnable() {
      public void run() {
        if (bluetooth != null && bluetooth.IsConnected()) {
          SensorValue<Boolean> sensorValue = getPressedValue("");
          if (sensorValue.valid) {
            State currentState = sensorValue.value ? State.PRESSED : State.RELEASED;

            if (currentState != previousState) {
              if (currentState == State.PRESSED && pressedEventEnabled) {
                Pressed();
              }
              if (currentState == State.RELEASED && releasedEventEnabled) {
                Released();
              }
            }

            previousState = currentState;
          }
        }
        if (isHandlerNeeded()) {
          handler.post(sensorReader);
        }
      }
    };

    SensorPort(DEFAULT_SENSOR_PORT);
    PressedEventEnabled(false);
    ReleasedEventEnabled(false);
  }

  @Override
  protected void initializeSensor(String functionName) {
    setInputMode(functionName, port, SENSOR_TYPE_SWITCH, SENSOR_MODE_BOOLEANMODE);
  }

  /**
   * Specifies the sensor port that the sensor is connected to.
   */
  @DesignerProperty(editorType = DesignerProperty.PROPERTY_TYPE_LEGO_NXT_SENSOR_PORT,
      defaultValue = DEFAULT_SENSOR_PORT)
  @SimpleProperty(userVisible = false)
  public void SensorPort(String sensorPortLetter) {
    setSensorPort(sensorPortLetter);
  }

  @SimpleFunction(description = "Returns true if the touch sensor is pressed.")
  public boolean IsPressed() {
    String functionName = "IsPressed";
    if (!checkBluetooth(functionName)) {
      return false;
    }

    SensorValue<Boolean> sensorValue = getPressedValue(functionName);
    if (sensorValue.valid) {
      return sensorValue.value;
    }

    // invalid response
    return false;
  }

  private SensorValue<Boolean> getPressedValue(String functionName) {
    byte[] returnPackage = getInputValues(functionName, port);
    if (returnPackage != null) {
      boolean valid = getBooleanValueFromBytes(returnPackage, 4);
      if (valid) {
        int scaledValue = getSWORDValueFromBytes(returnPackage, 12);
        return new SensorValue<Boolean>(true, (scaledValue != 0));
      }
    }

    // invalid response
    return new SensorValue<Boolean>(false, null);
  }

  /**
   * Returns whether the Pressed event should fire when the touch sensor is
   * pressed.
   */
  @SimpleProperty(description = "Whether the Pressed event should fire when the touch sensor is" +
      " pressed.",
      category = PropertyCategory.BEHAVIOR)
  public boolean PressedEventEnabled() {
    return pressedEventEnabled;
  }

  /**
   * Specifies whether the Pressed event should fire when the touch sensor is
   * pressed.
   */
  @DesignerProperty(editorType = DesignerProperty.PROPERTY_TYPE_BOOLEAN, defaultValue = "False")
  @SimpleProperty
  public void PressedEventEnabled(boolean enabled) {
    boolean handlerWasNeeded = isHandlerNeeded();

    pressedEventEnabled = enabled;

    boolean handlerIsNeeded = isHandlerNeeded();
    if (handlerWasNeeded && !handlerIsNeeded) {
      handler.removeCallbacks(sensorReader);
    }
    if (!handlerWasNeeded && handlerIsNeeded) {
      previousState = State.UNKNOWN;
      handler.post(sensorReader);
    }
  }

  @SimpleEvent(description = "Touch sensor has been pressed.")
  public void Pressed() {
    EventDispatcher.dispatchEvent(this, "Pressed");
  }

  /**
   * Returns whether the Released event should fire when the touch sensor is
   * released.
   */
  @SimpleProperty(description = "Whether the Released event should fire when the touch sensor is" +
      " released.",
      category = PropertyCategory.BEHAVIOR)
  public boolean ReleasedEventEnabled() {
    return releasedEventEnabled;
  }

  /**
   * Specifies whether the Released event should fire when the touch sensor is
   * released.
   */
  @DesignerProperty(editorType = DesignerProperty.PROPERTY_TYPE_BOOLEAN, defaultValue = "False")
  @SimpleProperty
  public void ReleasedEventEnabled(boolean enabled) {
    boolean handlerWasNeeded = isHandlerNeeded();

    releasedEventEnabled = enabled;

    boolean handlerIsNeeded = isHandlerNeeded();
    if (handlerWasNeeded && !handlerIsNeeded) {
      handler.removeCallbacks(sensorReader);
    }
    if (!handlerWasNeeded && handlerIsNeeded) {
      previousState = State.UNKNOWN;
      handler.post(sensorReader);
    }
  }

  @SimpleEvent(description = "Touch sensor has been released.")
  public void Released() {
    EventDispatcher.dispatchEvent(this, "Released");
  }

  private boolean isHandlerNeeded() {
    return pressedEventEnabled || releasedEventEnabled;
  }

  // Deleteable implementation

  @Override
  public void onDelete() {
    handler.removeCallbacks(sensorReader);
  }
}
