package com.Android.ladybug;

import com.google.devtools.simple.runtime.components.HandlesEventDispatching;

import com.google.devtools.simple.runtime.components.android.Button;
import com.google.devtools.simple.runtime.components.android.Canvas;
import com.google.devtools.simple.runtime.components.android.Clock;
import com.google.devtools.simple.runtime.components.android.Form;
import com.google.devtools.simple.runtime.components.android.ImageSprite;
import com.google.devtools.simple.runtime.components.android.OrientationSensor;
import com.google.devtools.simple.runtime.components.android.Sound;
import com.google.devtools.simple.runtime.events.EventDispatcher;

import java.util.Random;

public class LadybugChase extends Form implements HandlesEventDispatching
{
	private Canvas cnvFieldCanvas, cnvEnergyCanvas;
	private ImageSprite ispLadybug, ispAphid, ispFrog;
	private Button btnRestartButton;
	private OrientationSensor osnOrientationSensor1;
	private Clock clkClock1;
	private Sound sndSound1;
	
	private int energy = 200;
	
	void $define()
	{
		this.Title( "Ladybug Chase" );
		this.ScreenOrientation( "Portrait" );
		
		clkClock1 = new Clock( this );
		clkClock1.TimerInterval( 10 );
		
		osnOrientationSensor1 = new OrientationSensor( this );
		
		sndSound1 = new Sound( this );
		sndSound1.Source( "FROG.WAV" );
		
		cnvFieldCanvas = new Canvas( this );
		cnvFieldCanvas.Width( Canvas.LENGTH_FILL_PARENT );
		cnvFieldCanvas.Height( 300 );
		
		ispLadybug = new ImageSprite( cnvFieldCanvas );
		ispLadybug.Picture( "ladybug.png" );
		
		ispAphid = new ImageSprite( cnvFieldCanvas );
		ispAphid.Picture( "aphid.png" );
		
		ispFrog = new ImageSprite( cnvFieldCanvas );
		ispFrog.Picture( "frog.png" );
		
		cnvEnergyCanvas = new Canvas( this );
		cnvEnergyCanvas.Width( Canvas.LENGTH_FILL_PARENT );
		cnvEnergyCanvas.Height( 1 );
		
		btnRestartButton = new Button( this );
		btnRestartButton.Text( "Restart" );
		
		EventDispatcher.registerEventForDelegation( this, "LadybugChase", "Click" );
		EventDispatcher.registerEventForDelegation( this, "LadybugChase", "CollidedWith" );
		EventDispatcher.registerEventForDelegation( this, "LadybugChase", "Timer" );
	}
	
	public void dispatchEvent( Object component, String id, String eventName, Object[] args )
	{
		if( eventName.equals( "Click" ) && component.equals( btnRestartButton ))
			btnRestartButton_Click();
		else if( eventName.equals( "CollidedWith" ) && component.equals( ispLadybug ))
			ispLadybug_CollidedWith( args[0] );
		else if( eventName.equals( "Timer" ) && component.equals( clkClock1 ))
			clkClock1_Timer();
	}
	
	private void UpdateLadybug()
	{
		energy--;
		DisplayEnergy();
		
		if( energy == 0 )
			GameOver();
		
		ispLadybug.Heading( osnOrientationSensor1.Angle() );
		ispLadybug.Speed( osnOrientationSensor1.Magnitude() * 100.0f );
	}
	
	private void UpdateAphid()
	{
		if( ispAphid.Visible() )
		{
			if( new Random().nextDouble() < 0.2 )
				ispAphid.Heading( new Random().nextInt( 360 ));
		} else {
			if( new Random().nextDouble() < 0.05 )
			{
				ispAphid.Visible( true );
				ispAphid.Enabled( true );
			}
		}
	}
	
	private void DisplayEnergy()
	{
		DrawEnergyLine( Canvas.COLOR_WHITE, cnvEnergyCanvas.Width() );
		DrawEnergyLine( Canvas.COLOR_RED, energy );
	}
	
	private void GameOver()
	{
		ispLadybug.Enabled( false );
		ispLadybug.Picture( "dead_ladybug.PNG" );
	}
	
	private void DrawEnergyLine( int color, int length )
	{
		cnvEnergyCanvas.PaintColor( color );
		cnvEnergyCanvas.DrawLine( 0, 0, length, 0 );
	}
	
	private void btnRestartButton_Click()
	{
		ispLadybug.MoveTo( new Random().nextInt( cnvFieldCanvas.Width() - ispLadybug.Width() ), new Random().nextInt( cnvFieldCanvas.Height() - ispLadybug.Height() ));
		energy = 200;
		ispAphid.Visible( true );
		ispAphid.Enabled( true );
		ispLadybug.Enabled( true );
		ispLadybug.Picture( "ladybug.png" );
	}
	
	private void UpdateFrog()
	{
		if( new Random().nextDouble() < 0.1 )
			ispFrog.Heading( Math.atan2( ispFrog.Y() - ispLadybug.Y(), ispLadybug.X() - ispFrog.X()));
	}
	
	private void clkClock1_Timer()
	{
		UpdateLadybug();
		UpdateAphid();
		UpdateFrog();
	}
	
	private void EatAphid()
	{
		energy += 50;
		ispAphid.Visible( false );
		ispAphid.Enabled( false );
		ispAphid.MoveTo( new Random().nextInt( cnvFieldCanvas.Width() - ispAphid.Width()), new Random().nextInt( cnvFieldCanvas.Height() - ispAphid.Height()) );
	}
	
	private void ispLadybug_CollidedWith( Object other )
	{
	}
}
