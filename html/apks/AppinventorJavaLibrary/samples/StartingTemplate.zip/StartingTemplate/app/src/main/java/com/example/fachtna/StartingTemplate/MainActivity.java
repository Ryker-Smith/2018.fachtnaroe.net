package com.example.fachtna.StartingTemplate;

import android.content.Intent;

import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.TextBox;
import com.google.appinventor.components.runtime.VerticalScrollArrangement;
import com.google.appinventor.components.runtime.Web;

public class MainActivity extends Form implements HandlesEventDispatching
{
    private Button oneButton;
    private Button anotherButton;
    private Label oneLabel;
    private Web oneWebComponent;
    private VerticalScrollArrangement oneArrangement;
    private TextBox oneTextBox;
    private String remoteHost = "fachtnaroe.net";;


    protected void $define() {

        oneArrangement = new VerticalScrollArrangement(this);
        oneArrangement.WidthPercent(100);
        oneArrangement.HeightPercent(100);

        oneLabel = new Label(oneArrangement);
        oneLabel.Text("You could put some informative text here: ");

        oneTextBox = new TextBox(oneArrangement);
        oneTextBox.WidthPercent(100);
        oneTextBox.Text("https://" + remoteHost + "/generic?cmd=ver");

        oneButton = new Button(oneArrangement);
        oneButton.Text("Connect");
        oneButton.BackgroundColor(COLOR_LTGRAY);
        oneButton.WidthPercent(50);
        oneButton.TextAlignment(Component.ALIGNMENT_CENTER);

        anotherButton = new Button(oneArrangement);
        anotherButton.Text("Press for second screen");
        anotherButton.BackgroundColor(COLOR_LTGRAY);
        anotherButton.WidthPercent(50);
        anotherButton.TextAlignment(Component.ALIGNMENT_CENTER);

        oneWebComponent = new Web(oneArrangement);
        // prepare the App to receive events
        EventDispatcher.registerEventForDelegation( this, "oneButton", "Click" );
        EventDispatcher.registerEventForDelegation( this, "anotherButton", "Click" );
        EventDispatcher.registerEventForDelegation( this, "oneWebComponent", "GotText" );
    }

    public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params)
    {
        if (component.equals(oneButton) && eventName.equals("Click"))
        {
            connectionButtonClick();
            return true;
        }
        else if (component.equals(anotherButton) && eventName.equals("Click"))
        {
            secondScreen();
            return true;
        }
        else if (component.equals(oneWebComponent) && eventName.equals("GotText"))
        {
            String result = (String) params[3];
            youveGotText(result);
            return true;
        }
        else {
            oneLabel.Text("Unknown event");
            return false;
        }
    }

    public void connectionButtonClick() {
        String targetURL;
        oneButton.Text("Pressed, getting remote sample data: ");
        targetURL= oneTextBox.Text();
        oneWebComponent.Url(targetURL);
        oneWebComponent.Get();
    }

    public void youveGotText(String result) {
        oneButton.Text("Got data: ");
        oneTextBox.Text(result);
    }

    public void secondScreen() {
        oneButton.Text("second");
        startActivity(new Intent(MainActivity.this, SecondActivity.class));
    }

}
