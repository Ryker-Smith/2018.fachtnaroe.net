package com.example.fachtna.StartingTemplate;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Canvas;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.ImageSprite;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.TextBox;
import com.google.appinventor.components.runtime.VerticalArrangement;
import com.google.appinventor.components.runtime.VerticalScrollArrangement;
import com.google.appinventor.components.runtime.Web;

import static com.google.appinventor.components.runtime.Component.COLOR_LTGRAY;

public class SecondActivity extends Form implements HandlesEventDispatching {

    private Button oneButton, twoButton;
    private VerticalArrangement oneArrangement;
    private Canvas oneCanvas;
    private ImageSprite oneSprite;

    protected void $define() {

        oneArrangement = new VerticalArrangement(this);
        oneArrangement.WidthPercent(100);
        oneArrangement.HeightPercent(100);

        oneButton = new Button(oneArrangement);
        oneButton.Text("Close screen");
        oneButton.BackgroundColor(COLOR_LTGRAY);
        oneButton.WidthPercent(50);
        oneButton.TextAlignment(Component.ALIGNMENT_CENTER);

        twoButton = new Button(oneArrangement);
        twoButton.Text("Canvas");
        twoButton.BackgroundColor(COLOR_LTGRAY);
        twoButton.WidthPercent(50);
        twoButton.TextAlignment(Component.ALIGNMENT_CENTER);

        EventDispatcher.registerEventForDelegation( this, "oneButton", "Click" );
        EventDispatcher.registerEventForDelegation( this, "twoButton", "Click" );
    }

    public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params) {

        if (component.equals(oneButton) && eventName.equals("Click")) {
            SecondActivity.finishActivity();
            SecondActivity.finishActivityWithTextResult("Ends");
            return true;
        }
        else if (component.equals(twoButton) && eventName.equals("Click")) {
            oneCanvas = new Canvas(oneArrangement);
            twoButton.Text("Making a canvas");
            oneCanvas.WidthPercent(100);
            oneCanvas.HeightPercent(100);
            oneCanvas.BackgroundColor(
                    COLOR_LTGRAY
            );
            twoButton.Text("Making a sprite");
            oneSprite = new ImageSprite(oneCanvas);

            oneSprite.Picture("ladybug.png");

            oneSprite.Width(200);
            oneSprite.Height(200);
            oneSprite.Enabled(true);
            oneSprite.X(10);
            oneSprite.Y(10);
            oneSprite.Visible(true);
            twoButton.Text("Sprite made");
            return true;
        }
        else {
            return false;
        }

    }

}
