#!/usr/bin/perl
use strict;
use SDL;
use SDL::Video;
use SDLx::App;
use SDL::Surface;
use SDL::Rect;
use SDL::Image;
use SDL::Event;
use SDL::Mouse;
use SDLx::Sound;
#------------------------
# Declaring all the Variables
my ($screen);
my ($back, $back_rect, $dest_rect);
my ($Good_Guy, $Good_Guy_rect, $Good_Cover_Rect, $Good_Guy_x, $Good_Guy_y, $Good_Guy_h,
$Good_Guy_w);
my ($Bad_Guy_01, $Bad_Guy_01_x, $Bad_Guy_01_y, $Bad_Guy_01_w, $Bad_Guy_01_h,
$Bad_Guy_01_rect);
my ($Bad_Guy_02, $Bad_Guy_02_x, $Bad_Guy_02_y, $Bad_Guy_02_w, $Bad_Guy_02_h,
$Bad_Guy_02_rect);
my ($Bad_Guy_03, $Bad_Guy_03_x, $Bad_Guy_03_y, $Bad_Guy_03_w, $Bad_Guy_03_h,
$Bad_Guy_03_rect);
my ($Bad_Guy_04, $Bad_Guy_04_x, $Bad_Guy_04_y, $Bad_Guy_04_w, $Bad_Guy_04_h,
$Bad_Guy_04_rect);
my ($Bad_Guy_05, $Bad_Guy_05_x, $Bad_Guy_05_y, $Bad_Guy_05_w, $Bad_Guy_05_h,
$Bad_Guy_05_rect);
my ($event, $quit_event_handle, $mouse_event_handle, $key_event_handle,
$Bad_Guy_01_move_handle, $Bad_Guy_02_move_handle, $Bad_Guy_03_move_handle,
$Bad_Guy_04_move_handle, $Bad_Guy_01_show_handle, $Bad_Guy_05_move_handle,
$left_key_handle, $Bad_Guy_02_show_handle, $Bad_Guy_03_show_handle,
$Bad_Guy_04_show_handle,$Bad_Guy_05_show_handle);
my ($exiting, $movement);
my ($Cover);
my ($oldx_Good_Guy, $oldy_Good_Guy, $oldx_Bad_Guy_01, $oldy_Bad_Guy_01,
$oldx_Bad_Guy_02, $oldy_Bad_Guy_02, $oldx_Bad_Guy_03, $oldy_Bad_Guy_03,
$oldx_Bad_Guy_04, $oldy_Bad_Guy_04, $oldx_Bad_Guy_05, $oldy_Bad_Guy_05);
my ($pixel, $r, $g, $hex, $path_color,);
my ($bomb_sound, $playing);
my ($Bad_Guy_06, $Bad_Guy_06_x, $Bad_Guy_06_y, $Bad_Guy_06_w, $Bad_Guy_06_h,
$Bad_Guy_06_rect);
my ($oldx_Bad_Guy_06, $oldy_Bad_Guy_06);
my ($Bad_Guy_06_show_handle, $Bad_Guy_06_move_handle);
#my ($goal, $goal_x, $goal_y, $goal_h, $goal_w, $goal_rect, $goal_handle, $goal_move_handle,);
#------------------------
#Setting the Movement speed. (10 co-ordinates at a time)
$movement = 5;
#------------------------
#Creating the screen.
$screen = SDLx::App->new(
title  => "Maze of Hell",
width  => 800,
height => 600,
depth  => 32,
flags => SDL_HWSURFACE,
dt=>1,
exit_on_quit => 1);
#Creating all the Sub routines.
$quit_event_handle = $screen->add_event_handler(\&quit_event);

$key_event_handle = $screen->add_event_handler(\&key_event);

$Bad_Guy_01_move_handle = $screen->add_move_handler(\&Bad_Guy_01_move);

$Bad_Guy_02_move_handle = $screen->add_move_handler(\&Bad_Guy_02_move);

$Bad_Guy_03_move_handle = $screen->add_move_handler(\&Bad_Guy_03_move);

$Bad_Guy_04_move_handle = $screen->add_move_handler(\&Bad_Guy_04_move);

$Bad_Guy_05_move_handle = $screen->add_move_handler(\&Bad_Guy_05_move);

$Bad_Guy_06_move_handle = $screen->add_move_handler(\&Bad_Guy_06_move);

$Bad_Guy_01_show_handle = $screen->add_show_handler(\&Bad_Guy_01_show);

$Bad_Guy_02_show_handle = $screen->add_show_handler(\&Bad_Guy_02_show);

$Bad_Guy_03_show_handle = $screen->add_show_handler(\&Bad_Guy_03_show);

$Bad_Guy_04_show_handle = $screen->add_show_handler(\&Bad_Guy_04_show);

$Bad_Guy_05_show_handle = $screen->add_show_handler(\&Bad_Guy_05_show);

$Bad_Guy_06_show_handle = $screen->add_show_handler(\&Bad_Guy_06_move);

$left_key_handle = $screen->add_event_handler(\&mouse_event);

$screen->add_move_handler( \&simple_collision);

#------------------------

SDL::Video::update_rects($screen);

$back = SDL::Image::load('Start_screen.jpg');
$Cover = $back;
$back_rect = SDL::Rect->new(0,0, $back->w, $back->h);

SDL::Video::blit_surface($back, $back_rect, $screen, $back_rect
);
SDL::Video::update_rects($screen, $back_rect);
sleep(5);

#Drawing the back
$back = SDL::Image::load('BG_01.jpg');
$Cover = $back;
$back_rect = SDL::Rect->new(0,0, $back->w, $back->h);
$event = SDL::Event->new();
#------------------------

#Drawinf the Second Character (Bad Guy)
SDL::Video::blit_surface($back, $back_rect, $screen, $back_rect);
$Bad_Guy_01 = SDL::Image::load('Character_02.jpg');
$Bad_Guy_01_x = 0;
$Bad_Guy_01_y = 0;
$Bad_Guy_01_w = $Bad_Guy_01->w;
$Bad_Guy_01_h = $Bad_Guy_01->h;
$Bad_Guy_01_rect = SDL::Rect->new($Bad_Guy_01_x, $Bad_Guy_01_y, $Bad_Guy_01_w,
$Bad_Guy_01_h,);
SDL::Video::blit_surface ($Bad_Guy_01, $Bad_Guy_01_rect, $screen, $Bad_Guy_01_rect);
SDL::Video::update_rects($screen, $Bad_Guy_01_rect);
#-------------------------

#Third
SDL::Video::blit_surface($back, $back_rect, $screen, $back_rect );
$Bad_Guy_02 = SDL::Image::load('Character_03.jpg');
$Bad_Guy_02_x = 0;
$Bad_Guy_02_y = 0;
$Bad_Guy_02_w = $Bad_Guy_02->w;
$Bad_Guy_02_h = $Bad_Guy_02->h;
$Bad_Guy_02_rect = SDL::Rect->new($Bad_Guy_02_x, $Bad_Guy_02_y, $Bad_Guy_02_w,
$Bad_Guy_02_h);
#SDL::Video::blit_surface ($Bad_Guy_02, $Bad_Guy_02_rect, $screen, $Bad_Guy_02_rect);
SDL::Video::update_rects($screen, $Bad_Guy_02_rect, $back_rect);

SDL::Video::blit_surface($back, $back_rect, $screen, $back_rect);
$Bad_Guy_03 = SDL::Image::load('Character_04.jpg');
$Bad_Guy_03_x = 0;
$Bad_Guy_03_y = 0;
$Bad_Guy_03_w = $Bad_Guy_03->w;
$Bad_Guy_03_h = $Bad_Guy_03->h;
$Bad_Guy_03_rect = SDL::Rect->new($Bad_Guy_03_x, $Bad_Guy_03_y, $Bad_Guy_03_w,
$Bad_Guy_03_h,);
SDL::Video::blit_surface ($Bad_Guy_03, $Bad_Guy_03_rect, $screen, $Bad_Guy_03_rect);
SDL::Video::update_rects($screen, $Bad_Guy_03_rect);
#----------------------

SDL::Video::blit_surface($back, $back_rect, $screen, $back_rect);
$Bad_Guy_04 = SDL::Image::load('Character_05.jpg');
$Bad_Guy_04_x = 0;
$Bad_Guy_04_y = 0;
$Bad_Guy_04_w = $Bad_Guy_04->w;
$Bad_Guy_04_h = $Bad_Guy_04->h;
$Bad_Guy_04_rect = SDL::Rect->new($Bad_Guy_04_x, $Bad_Guy_04_y, $Bad_Guy_04_w,
$Bad_Guy_04_h,);
SDL::Video::blit_surface ($Bad_Guy_04, $Bad_Guy_04_rect, $screen, $Bad_Guy_04_rect);
SDL::Video::update_rects($screen, $Bad_Guy_04_rect);
#----------------------

SDL::Video::blit_surface($back, $back_rect, $screen, $back_rect );
$Bad_Guy_05 = SDL::Image::load('Character_06.jpg');
$Bad_Guy_05_x = 0;
$Bad_Guy_05_y = 0;
$Bad_Guy_05_w = $Bad_Guy_05->w;
$Bad_Guy_05_h = $Bad_Guy_05->h;
$Bad_Guy_05_rect = SDL::Rect->new($Bad_Guy_05_x, $Bad_Guy_05_y, $Bad_Guy_05_w,
$Bad_Guy_05_h);
#SDL::Video::blit_surface ($Bad_Guy_05, $Bad_Guy_05_rect, $screen, $Bad_Guy_05_rect);
SDL::Video::update_rects($screen, $Bad_Guy_05_rect, $back_rect);
#------------------------
#Drawinf the Second Character (Bad Guy)

SDL::Video::blit_surface($back, $back_rect, $screen, $back_rect);
$Bad_Guy_06 = SDL::Image::load('Goal.jpg');
$Bad_Guy_06_x = 0;
$Bad_Guy_06_y = 0;
$Bad_Guy_06_w = $Bad_Guy_06->w;
$Bad_Guy_06_h = $Bad_Guy_06->h;
$Bad_Guy_06_rect = SDL::Rect->new($Bad_Guy_06_x, $Bad_Guy_06_y, $Bad_Guy_06_w,
$Bad_Guy_06_h,);
SDL::Video::blit_surface ($Bad_Guy_06, $Bad_Guy_06_rect, $screen, $Bad_Guy_06_rect);
SDL::Video::update_rects($screen, $Bad_Guy_06_rect);
#-------------------------
#SDL::Video::blit_surface($back, $back_rect, $screen, $back_rect);
#$goal = SDL::Image::load('Goal.jpg');
#$goal_x = 70;
#$goal_y = 70;
#$goal_w = $Bad_Guy_04->w;
#$goal_h = $Bad_Guy_04->h;
#$goal_rect = SDL::Rect->new($goal_x, $goal_y, $goal_w, $goal_h);
#SDL::Video::blit_surface ($goal, $goal_rect, $screen, $goal_rect);#
#SDL::Video::update_rects($screen, $goal_rect);
#-------------------------------
#Drawing the First Character (Good Guy)
SDL::Video::blit_surface($back, $back_rect, $screen, $back_rect );
$Good_Guy = SDL::Image::load('Character_01.gif');
$Good_Guy_x = 750;
$Good_Guy_y = 550;
$Good_Guy_w = $Good_Guy->w;
$Good_Guy_h = $Good_Guy->h;
$Good_Guy_rect = SDL::Rect->new(0, 0 ,$Good_Guy_w ,$Good_Guy_h);
my $temp_rect = SDL::Rect->new($Good_Guy_x, $Good_Guy_y ,$Good_Guy_w ,$Good_Guy_h);
SDL::Video::blit_surface ($Good_Guy, $Good_Guy_rect, $screen, $temp_rect);
SDL::Video::blit_surface($back, $back_rect, $screen, $back_rect);
SDL::Video::update_rects($screen, $Good_Guy, $temp_rect, $back_rect);
#------------------------
$exiting = 0;
# 20130416 changed for testing:
SDL::Events::enable_key_repeat(80, 25);
my $Bad_Guy_01_Step = 6;
my $Bad_Guy_01_Upper = 650;
my $Bad_Guy_01_Lower = 290;
my $Bad_Guy_01_x = 730;
my $Bad_Guy_01_y = 150;

my $Bad_Guy_02_Step = 7;
my $Bad_Guy_02_Upper = 500;
my $Bad_Guy_02_Lower = 30;
my $Bad_Guy_02_x = 30;
my $Bad_Guy_02_y = 20;

my $Bad_Guy_03_Step = 6;
my $Bad_Guy_03_Upper = 470;
my $Bad_Guy_03_Lower = 30;
my $Bad_Guy_03_x = 240;
my $Bad_Guy_03_y = 530;

my $Bad_Guy_04_Step = 7;
my $Bad_Guy_04_Upper = 750;
my $Bad_Guy_04_Lower = 300;
my $Bad_Guy_04_x = 800,
my $Bad_Guy_04_y = 475;

my $Bad_Guy_05_Step = 6;
my $Bad_Guy_05_Upper = 500;
my $Bad_Guy_05_Lower = 30;
my $Bad_Guy_05_x = 740;
my $Bad_Guy_05_y = 200;

my $Bad_Guy_06_Step = 5;
my $Bad_Guy_06_Upper = 550;
my $Bad_Guy_06_Lower = 540;
my $Bad_Guy_06_x = 30;
my $Bad_Guy_06_y = 560;

#my $goal_Step = 0;
#my $goal_Upper = 0;
#my $goal_Lower = 0;
#my $goal_x = 10,
#my $goal_y = 10;

# Start the game loop
$path_color=5915629;
my ($unpath) = 16777215;
# whatever color is allowed for navigation
# 20130416: added to make sure gg displayed at start:
&display ($Good_Guy_x, $Good_Guy_y, $oldx_Good_Guy, $Good_Guy_y);

$screen->run;

sub Bad_Guy_01_move {
	my ($step, $screen, $t) = @_;
	if ($step < .01) {
		return;
	}

	$oldx_Bad_Guy_01 = $Bad_Guy_01_x;
	$oldy_Bad_Guy_01 = $Bad_Guy_01_y;
	$Bad_Guy_01_x+= $Bad_Guy_01_Step; # change x by +/- step

	if ($Bad_Guy_01_x > $Bad_Guy_01_Upper) { # limit test
		$Bad_Guy_01_x = $Bad_Guy_01_Upper;
		$Bad_Guy_01_Step*= -1; # invert step
	}
	elsif ($Bad_Guy_01_x < $Bad_Guy_01_Lower) {# limit test
		$Bad_Guy_01_x = $Bad_Guy_01_Lower;
		$Bad_Guy_01_Step*= -1; # invert step
	}
}
#------------------------

sub Bad_Guy_02_move {
	my ($step, $screen, $t) = @_;
	$oldx_Bad_Guy_02 = $Bad_Guy_02_x;
	$oldy_Bad_Guy_02 = $Bad_Guy_02_y;
	$Bad_Guy_02_y+= $Bad_Guy_02_Step;

	if ($Bad_Guy_02_y > $Bad_Guy_02_Upper) {
		$Bad_Guy_02_y = $Bad_Guy_02_Upper;
		$Bad_Guy_02_Step*= -1;
	}
	if ($Bad_Guy_02_y < $Bad_Guy_02_Lower) {
		$Bad_Guy_02_y = $Bad_Guy_02_Lower;
		$Bad_Guy_02_Step*= -1;
	}
}
sub Bad_Guy_03_move {
	my ($step, $screen, $t) = @_;
	$oldx_Bad_Guy_03 = $Bad_Guy_03_x;
	$oldy_Bad_Guy_03 = $Bad_Guy_03_y;
	$Bad_Guy_03_y+= $Bad_Guy_03_Step;
	
	if ($Bad_Guy_03_y > $Bad_Guy_03_Upper) {
		$Bad_Guy_03_y = $Bad_Guy_03_Upper;
		$Bad_Guy_03_Step*= -1;
	}
	if ($Bad_Guy_03_y < $Bad_Guy_03_Lower) {
		$Bad_Guy_03_y = $Bad_Guy_03_Lower;
		$Bad_Guy_03_Step*= -1;
	}
}
sub Bad_Guy_04_move {
	my ($step, $screen, $t) = @_;
	$oldx_Bad_Guy_04 = $Bad_Guy_04_x;
	$oldy_Bad_Guy_04 = $Bad_Guy_04_y;	
	$Bad_Guy_04_x+= $Bad_Guy_04_Step;

	if ($Bad_Guy_04_x > $Bad_Guy_04_Upper) {
		$Bad_Guy_04_x = $Bad_Guy_04_Upper;
		$Bad_Guy_04_Step*= -1;
	}
	if ($Bad_Guy_04_x < $Bad_Guy_04_Lower) {
		$Bad_Guy_04_x = $Bad_Guy_04_Lower;
		$Bad_Guy_04_Step*= -1;
	}
}
sub Bad_Guy_05_move {
	my ($step, $screen, $t) = @_;
	$oldx_Bad_Guy_05 = $Bad_Guy_05_x;
	$oldy_Bad_Guy_05 = $Bad_Guy_05_y;
	$Bad_Guy_05_y+= $Bad_Guy_05_Step;
	if ($Bad_Guy_05_y > $Bad_Guy_05_Upper) {
		$Bad_Guy_05_y = $Bad_Guy_05_Upper;
		$Bad_Guy_05_Step*= -1;
	}
	if ($Bad_Guy_05_y < $Bad_Guy_05_Lower) {
		$Bad_Guy_05_y = $Bad_Guy_05_Lower;
		$Bad_Guy_05_Step*= -1;
	}
}
sub Bad_Guy_06_move {
	my ($step, $screen, $t) = @_;
	$oldx_Bad_Guy_06 = $Bad_Guy_06_x;
	$oldy_Bad_Guy_06 = $Bad_Guy_06_y;
	$Bad_Guy_06_x+= $Bad_Guy_06_Step; # change x by +/- step
	if ($Bad_Guy_06_x > $Bad_Guy_06_Upper) { # limit test
		$Bad_Guy_06_x = $Bad_Guy_06_Upper;
		$Bad_Guy_06_Step*= -1; # invert step
	}
	elsif ($Bad_Guy_06_x < $Bad_Guy_06_Lower) {# limit test
		$Bad_Guy_06_x = $Bad_Guy_06_Lower;
		$Bad_Guy_06_Step*= -1; # invert step
	}
}
#sub goal_move {
#  my ($step, $screen, $t) = @_;
# if ($goal_x > $goal_Upper) {
#      $goal_x = $goal_Upper;
#     $goal_Step*= -1;
#  }
# if ($goal_x < $goal_Lower) {
#     $goal_x = $goal_Lower;
#    $goal_Step*= -1;
# }
#}
sub Bad_Guy_01_show {	
	my ($delta, $screen) = @_;
	my ($dest_rect);
#    my ($oldx_Bad_Guy01, $oldy_Bad_Guy01, $oldx_Bad_Guy01_02, $oldy_Bad_Guy01_02);
	$dest_rect = SDL::Rect->new($Bad_Guy_01_x, $Bad_Guy_01_y, $Bad_Guy_01->w, $Bad_Guy_01->w);
	my $Cover_rect = SDL::Rect->new($oldx_Bad_Guy_01, $oldy_Bad_Guy_01, $Bad_Guy_01->w,$Bad_Guy_01->h);
# print "[$oldx_Bad_Guy01][$Bad_Guy_01_x]\n";
	SDL::Video::blit_surface($Cover, $Cover_rect, $screen, $Cover_rect);
	SDL::Video::blit_surface($Bad_Guy_01, $Bad_Guy_01_rect, $screen, $dest_rect);
	SDL::Video::update_rects($screen, $Cover_rect, $dest_rect);
}
sub Bad_Guy_02_show {
	my ($delta, $screen) = @_;
	my ($dest_rect);
	$dest_rect = SDL::Rect->new($Bad_Guy_02_x, $Bad_Guy_02_y ,$Bad_Guy_02->w ,$Bad_Guy_02->h);
	my $Cover_rect = SDL::Rect->new($oldx_Bad_Guy_02, $oldy_Bad_Guy_02, $Bad_Guy_02->w,
	$Bad_Guy_02->h);
	SDL::Video::blit_surface($Cover, $Cover_rect, $screen, $Cover_rect);
	SDL::Video::blit_surface($Bad_Guy_02, $Bad_Guy_02_rect, $screen, $dest_rect);
	SDL::Video::update_rects($screen, $Cover_rect, $dest_rect);
}
sub Bad_Guy_03_show {
	my ($delta, $screen) = @_;
	my ($dest_rect);
	#my ($oldx_Bad_Guy03, $oldy_Bad_Guy03, $oldx_Bad_Guy03_02, $oldy_Bad_Guy03_02);
	$dest_rect = SDL::Rect->new($Bad_Guy_03_x, $Bad_Guy_03_y, $Bad_Guy_03->w, $Bad_Guy_03->w);
	my $Cover_rect = SDL::Rect->new($oldx_Bad_Guy_03, $oldy_Bad_Guy_03, $Bad_Guy_03->w,
	$Bad_Guy_03->h);
	# print "[$oldx_Bad_Guy03][$Bad_Guy_03_x]\n";
	SDL::Video::blit_surface($Cover, $Cover_rect, $screen, $Cover_rect);
	SDL::Video::blit_surface($Bad_Guy_03, $Bad_Guy_03_rect, $screen, $dest_rect);
	SDL::Video::update_rects($screen, $Cover_rect, $dest_rect);
}
sub Bad_Guy_04_show {
	my ($delta, $screen) = @_;
	my ($dest_rect);
	#    my ($oldx_Bad_Guy04, $oldy_Bad_Guy04, $oldx_Bad_Guy04_04, $oldy_Bad_Guy04_04);
	$dest_rect = SDL::Rect->new($Bad_Guy_04_x, $Bad_Guy_04_y, $Bad_Guy_04->w, $Bad_Guy_04->w);
	my $Cover_rect = SDL::Rect->new($oldx_Bad_Guy_04, $oldy_Bad_Guy_04, $Bad_Guy_04->w,
	$Bad_Guy_04->h);
	# print "[$oldx_Bad_Guy04][$Bad_Guy_04_x]\n";
	SDL::Video::blit_surface($Cover, $Cover_rect, $screen, $Cover_rect);
	SDL::Video::blit_surface($Bad_Guy_04, $Bad_Guy_04_rect, $screen, $dest_rect);
	SDL::Video::update_rects($screen, $Cover_rect, $dest_rect);
}

sub Bad_Guy_05_show {
	my ($delta, $screen) = @_;
	my ($dest_rect);
	$dest_rect = SDL::Rect->new($Bad_Guy_05_x, $Bad_Guy_05_y ,$Bad_Guy_05->w ,$Bad_Guy_05->h);
	my $Cover_rect = SDL::Rect->new($oldx_Bad_Guy_05, $oldy_Bad_Guy_05, $Bad_Guy_05->w,
	$Bad_Guy_05->h);
	SDL::Video::blit_surface($Cover, $Cover_rect, $screen, $Cover_rect);
	SDL::Video::blit_surface($Bad_Guy_05, $Bad_Guy_05_rect, $screen, $dest_rect);
	SDL::Video::update_rects($screen, $Cover_rect, $dest_rect);
}
sub Bad_Guy_06_show {
	my ($delta, $screen) = @_;
	my ($dest_rect);
	#    my ($oldx_Bad_Guy06, $oldy_Bad_Guy06, $oldx_Bad_Guy06_02, $oldy_Bad_Guy06_02);
	$dest_rect = SDL::Rect->new($Bad_Guy_06_x, $Bad_Guy_06_y, $Bad_Guy_06->w, $Bad_Guy_06->w);
	my $Cover_rect = SDL::Rect->new($oldx_Bad_Guy_06, $oldy_Bad_Guy_06, $Bad_Guy_06->w,
	$Bad_Guy_06->h);
	# print "[$oldx_Bad_Guy06][$Bad_Guy_06_x]\n";
	SDL::Video::blit_surface($Cover, $Cover_rect, $screen, $Cover_rect);
	SDL::Video::blit_surface($Bad_Guy_06, $Bad_Guy_06_rect, $screen, $dest_rect);
	SDL::Video::update_rects($screen, $Cover_rect, $dest_rect);
}
#sub goal {
	# my ($delta, $screen) = @_;
	#  my ($dest_rect);
	#  #    my ($oldx_Bad_Guy04, $oldy_Bad_Guy04, $oldx_Bad_Guy04_04, $oldy_Bad_Guy04_04);
	#  $dest_rect = SDL::Rect->new($goal_x, $goal_y, $goal->w, $goal->w);
	# my $Cover_rect = SDL::Rect->new($goal->w, $goal->h);
	# print "[$oldx_Bad_Guy04][$Bad_Guy_04_x]\n";
	# SDL::Video::blit_surface($Cover, $Cover_rect, $screen, $Cover_rect);
	# SDL::Video::blit_surface($goal, $goal_rect, $screen);
	# SDL::Video::update_rects($screen, $Cover_rect);
#}
#------------------------
sub display {
	#  print "Dis\n";
	my ($x, $y, $old_x, $old_y)= @_;
	#     print "[old_x->$old_x][$x][old_y->$old_y][$y]\n";
	my $dest_rect = SDL::Rect->new($x, $y, $Good_Guy->w, $Good_Guy->h);
	my $Cover_rect = SDL::Rect->new($old_x, $old_y, $Good_Guy->w, $Good_Guy->h);
	# 20130416: re-added: 
	SDL::Video::blit_surface($Cover, $Cover_rect, $screen, $Cover_rect);
	SDL::Video::blit_surface($Good_Guy, $Good_Guy_rect, $screen, $dest_rect);
	# 20130416 removed this next: 
	#  SDL::Video::blit_surface($back, $back_rect, $screen, $back_rect);
	#  SDL::Video::update_rect($screen, 0, 0, $Good_Guy_w, $Good_Guy_h);
	# 20130416 amended: was:   SDL::Video::update_rects($screen, $Good_Guy_rect, $dest_rect);
	SDL::Video::update_rects($screen, $Cover_rect, $dest_rect);
}
#------------------------
sub simple_collision {
	use constant g => 100;
	my ($step, $screen, $t) = @_;
	my $distance = sqrt (($Bad_Guy_01_x - $Good_Guy_x)**2 + ($Bad_Guy_01_y - $Good_Guy_y)**2);
	$distance=int($distance);
	if ($distance < 50) {
		print "Oops. You were caught by The Enemy!.\n";
		$screen->stop;
	}
	my ($step, $screen, $t) = @_;
	my $distance = sqrt (($Bad_Guy_02_x - $Good_Guy_x)**2 + ($Bad_Guy_02_y - $Good_Guy_y)**2);
	$distance=int($distance);
	if ($distance < 40) {
		print "Oops. You were caught by The Enemy!.\n";
		$screen->stop;
	}
	my ($step, $screen, $t) = @_;
	my $distance = sqrt (($Bad_Guy_03_x - $Good_Guy_x)**2 + ($Bad_Guy_03_y - $Good_Guy_y)**2);
	$distance=int($distance);
	if ($distance < 40) {
		print "Oops. You were caught by The Enemy!.\n";
		$screen->stop;
	}
	my ($step, $screen, $t) = @_;
	my $distance = sqrt (($Bad_Guy_04_x - $Good_Guy_x)**2 + ($Bad_Guy_04_y - $Good_Guy_y)**2);
	$distance=int($distance);
	if ($distance < 40) {
		print "Oops. You were caught by The Enemy!.\n";
		$screen->stop;
	}

	my ($step, $screen, $t) = @_;
	my $distance = sqrt (($Bad_Guy_05_x - $Good_Guy_x)**2 + ($Bad_Guy_05_y - $Good_Guy_y)**2);
	$distance=int($distance);
	if ($distance < 40) {
		print "Oops. You were caught by The Enemy!.\n";
		$screen->stop;
	}

	my ($step, $screen, $t) = @_;
	my $distance = sqrt (($Bad_Guy_06_x - $Good_Guy_x)**2 + ($Bad_Guy_06_y - $Good_Guy_y)**2);
	$distance=int($distance);
	if ($distance < 50) {
		print "\n\nYou Succesfully Completed the game! Congratulations!!\n\n";
		$screen->stop;
	}
}
#------------------------
sub mouse_event {
	my ($event, $screen) = @_;
	my ($mouse_mask,$mouse_x,$mouse_y)  = @{SDL::Events::get_mouse_state()};
	my ($r, $g, $b, $pixel, $hex);
	if ($mouse_mask & SDL_BUTTON_LMASK) {
		$pixel =SDL::Surface::get_pixel($screen, $back->w*$mouse_y+$mouse_x);
		($r, $g, $b) = @{SDL::Video::get_RGB($screen->format(), $pixel)};
		# print "R[$r] G[$g] B[$b]\n";
		#print "Decimal[$pixel]\n";
		$hex = sprintf("%x",$pixel);
		# print "Hex[$hex]\n";
	}
}
#------------------------
	sub key_event {
	my ($event, $screen) = @_;
	my $key_name = SDL::Events::get_key_name( $event->key_sym );
	if (($key_name eq "q") || ($key_name eq "Q") ) {
		$screen->stop;
	}
	elsif (($key_name eq "x") || ($key_name eq "X") ) {
		$screen->stop;
	}
	#    if ($Good_Guy_x >775) {
	#        $Good_Guy_x = 780;
	#  }
	# if ($Good_Guy_y<10) {
	#     $Good_Guy_y = 0;
	#    }
	#   if ($Good_Guy_y>575) {
	#       $Good_Guy_y = 580;
	# }
	#if ($Good_Guy_x <10) {
	#            $Good_Guy_x = 0;
	#   }

	elsif ($key_name eq "right") {
		$oldx_Good_Guy = $Good_Guy_x;
		($Good_Guy_x, $Good_Guy_y)=&color_move ($Good_Guy_x, $Good_Guy_y, $movement, 0);
		&display ($Good_Guy_x, $Good_Guy_y, $oldx_Good_Guy, $Good_Guy_y);
		&simple_collision;
	} 
	elsif ($key_name eq "up") {
		$oldy_Good_Guy = $Good_Guy_y;
		($Good_Guy_x, $Good_Guy_y)=&color_move ($Good_Guy_x, $Good_Guy_y, 0, $movement*-1);
		&display ($Good_Guy_x, $Good_Guy_y, $Good_Guy_x, $oldy_Good_Guy);
		&simple_collision;
	}
	elsif ($key_name eq "left") {
		$oldx_Good_Guy = $Good_Guy_x;
		($Good_Guy_x, $Good_Guy_y)=&color_move ($Good_Guy_x, $Good_Guy_y, $movement*-1, 0);
		&display ($Good_Guy_x, $Good_Guy_y, $oldx_Good_Guy, $Good_Guy_y);
		&simple_collision;
	}
	elsif ($key_name eq "down") {
		$oldy_Good_Guy = $Good_Guy_y;
		($Good_Guy_x, $Good_Guy_y)=&color_move ($Good_Guy_x, $Good_Guy_y, 0, $movement);
		&display ($Good_Guy_x, $Good_Guy_y, $Good_Guy_x, $oldy_Good_Guy);
		&simple_collision;
	}
}

sub color_move {
	# 20130416: vars $Good_Guy_x -> becomes $present_x,
	# $Good_Guy_y -> $present_y
	my ($present_x, $present_y, $delta_x, $delta_y)= @_;
	my ($stored_x, $stored_y) = ($present_x, $present_y);
	#    print "X[$present_x][$delta_x]\n";
	#    print "Y[$present_y][$delta_y]\n";
	$present_x += $delta_x;
	$present_y += $delta_y;
	#    print "X[$present_x][$delta_x]\n";
	#    print "Y[$present_y][$delta_y]\n";
	#   return ($present_x, $present_y);
	# print "GG_w[",$Good_Guy->w,"][",$Good_Guy->h,"]\n";
	my $topleft=$back->w*$present_y+$present_x;
	#    my $topright=$back->w*$present_y+$present_x+$Good_Guy->w;
	my $botright=$back->w*($present_y+$Good_Guy->h+1)+$present_x+$Good_Guy->w+1;
	#print "testing: top left[$topleft]\n";
	#print "testing: bot right[$botright]\n";
	#    $screen->set_pixel( (800*550)+750, 0);
	my $test_01=SDL::Surface::get_pixel($screen, $topleft); # Top Left
	#    my $test_02=SDL::Surface::get_pixel($screen, $topright);# Top Right
	my $test_03=SDL::Surface::get_pixel($screen, $botright); #bottom right
	#    my $test_04=SDL::Surface::get_pixel($screen,
	$back->w*($present_y+$Good_Guy->h)+$present_x;# Bottom Left
#	print "Want:[$path_color]Got:
	#t01[$test_01]t02[$test_03]\n";#[$test_03][$test_04][$path_color]\n";
	if (($test_01 == $unpath) || ($test_03 == $unpath)){   #|| ($test_03 != $path_color) ) {
		# || ($test_02 != $path_color) || ($test_04 != $path_color)) {
#		print "Color FAIL\n";
		return ($stored_x, $stored_y);
	}
	else {
#		print "Color OK\n";
		return ($present_x, $present_y);
	}
}
#------------------------
sub quit_event {
	my ($event, $screen) = @_;
	if($event->type == SDL_QUIT) {
		$screen->stop;
	}
}

