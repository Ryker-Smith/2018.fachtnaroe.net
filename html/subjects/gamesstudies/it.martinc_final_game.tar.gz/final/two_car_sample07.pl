#!/usr/bin/perl
use strict;
use SDL; #needed to get all constants
use SDL::Video;
use SDLx::App;
#use SDL::App;
use SDL::Surface;
use SDL::Rect;
use SDL::Image;
use SDL::Event;
use SDL::Mouse;
my ($exiting, $moving, $mid_x, $mid_y, $step, $goodguy_step, $goodguy_x, $loud_x, $key_name );
my ($application, $background, $background_rect, $event, $filename, $goodguy, $goodguy_rect, $goodguy_x, $goodguy_y);
my ($granularity, $goodguy_x_min, $goodguy_x_max, $goodguy_y_min, $goodguy_y_max, $badguy_step, $goodguy_step ) = (5, 0, 750, 0, 550, 3);
my ($cover, $counter, $old_y, $old_golfball_y, $rocket_x, $rocket_y);
my ($dropping, $bomb_y, $bomb_x, $alien, $alien_y, $drop_control_move, $drop_control_show); 
my ($badguy_x, $badguy_y, $badguy_rect, $old_badguy_y, $badguy);
my ($golfball, $golfball_x, $golfball_y, $golfballmaster, $golfball_rect, $golfball_step, $new_golfball_rect, $new_ship_rect, $old_ship_rect, $old_golfball_x, $old_ship_x, $app );
my ($golfballX1, $golfballY1, $golfballX2, $golfballY2, $gollball2, $golfball_x_min, $golfball_x_max, $badguyY1,  $badguyY2, $badguyX1, $badguyX2);  
my ($new_badguy_rect, $cover_rect, $old_x, $alien_x, $alien_step );
my ($badguymaster, $goodguymaster);
my ($firing, $fire_control_move, $fire_control_show); 
# First create a new App
$application = SDLx::App->new(
    title  => "Golf Cart Blast",
    width  => 800, # use same width as background image
    height => 600, # use same height as background image
    depth  => 16, 
    exit_on_quit => 1 # Enable 'X' button
);
$application->add_event_handler( \&quit_event);
$application->add_event_handler( \&key_event);
$application->add_move_handler( \&move_alien);
$application->add_show_handler( \&show_alien);
#$application->add_move_handler( \&drop_bomb);
#$application->add_show_handler( \&show_bomb);
$application->add_event_handler( \&mouse_event);
$application->add_move_handler( \&move_badguy);
$application->add_show_handler( \&show_badguy);
$application->add_move_handler( \&move_rocket);
$application->add_show_handler( \&show_rocket);
$application->add_move_handler( \&simple_collision);
# Set up the background image + rectangle
$filename = "game background01.jpg";
$background = SDL::Image::load($filename);
$cover = $background;
$background_rect = SDL::Rect->new(0,0,$background->w,$background->h);

# load and prepare the badguy
$filename = "game foreground cart.gif";
$badguy = SDL::Image::load($filename);
# first set a master copy for later copying
$badguymaster = SDL::Rect->new(0, 0, $badguy->w, $badguy->h);
$badguy_x = 100;
$badguy_y = 100;
# now set up the start for the b-g
$badguy_rect = SDL::Rect->new($badguy_x,$badguy_y,$badguy->w,$badguy->h);

# prepare the good guy
$filename = "game foreground ball.gif";
$goodguy = SDL::Image::load($filename);
# make master recatngle for later copying
$goodguymaster = SDL::Rect->new(0, 0,$goodguy->w,$goodguy->h);
# now do the actual start for the g-g
$goodguy_x = 200;
$goodguy_y = 500;
$goodguy_rect = SDL::Rect->new($goodguy_x,$goodguy_y,$goodguy->w,$goodguy->h,);

$filename = "golfball01.gif";
$golfball = SDL::Image::load($filename);
# make master recatngle for later copying
$golfballmaster = SDL::Rect->new(0, 0,$golfball->w,$golfball->h);
# now do the actual start for the g-g
$golfball_x = 200;
$golfball_y = 500;
$golfball_rect = SDL::Rect->new($golfball_x,$golfball_y,$golfball->w,$golfball->h,);

SDL::Video::blit_surface($background, $background_rect, $application, $background_rect );
SDL::Video::blit_surface ($goodguy, $goodguymaster, $application, $goodguy_rect);
SDL::Video::blit_surface ($badguy, $badguymaster, $application, $badguy_rect);
SDL::Video::blit_surface ($golfball, $golfballmaster, $application, $golfball_rect);
SDL::Video::update_rects($application, $goodguy_rect, $badguy_rect, $background_rect, $background_rect);

# set key repeat on after 100ms, then every 0ms
SDL::Events::enable_key_repeat(100, 1);
$event = SDL::Event->new();
# Start the game loop
$application->run();
$counter = 0;
$exiting = 0;
sub move_badguy {
  # Calculate where the bad guy should be
  my ($step, $app, $t) = @_;
  my ($direction, $moving, $path_color, $test);
  $path_color=14132992; # whatever color is allowed for navigation
  $moving=0;
  # store x,y for later use
  $old_x = $badguy_x;
  $old_y = $badguy_y;
  # if we're trying to move left
  $badguy_x -= $badguy_step*$step;
  $mid_x= int ($badguy_x+$badguy->w/2);
  $mid_y= int ($badguy_y+$badguy->h/2);
  $test=SDL::Surface::get_pixel($app, $background->w*$badguy_y+$badguy_x);
  if ($test==$path_color) {
    $badguy_y+=10;
           # good future location, we'll allow the move
  }
  my ($direction, $moving, $path_color, $test);
  $path_color=56588; # whatever color is allowed for navigation
  $moving=0;
  # store x,y for later use
  # if we're trying to move left
  $badguy_x -= $badguy_step*$step;
  $mid_x= int ($badguy_x+$badguy->w/2);
  $mid_y= int ($badguy_y+$badguy->h/2);
  $test=SDL::Surface::get_pixel($app, $background->w*$badguy_y+$badguy_x);
    if ($test==$path_color) {
      $badguy_y+=20;
           # good future location, we'll allow the move
  }
  $badguy_x+=$badguy_step;
    if ($badguy_x > 650){
      $badguy_x = 650;
      $badguy_step *= -1;
      $counter=$counter+1;
    } 
    elsif ($badguy_x < 50) {
      $badguy_x = 50;
      $badguy_step *= -1;  
      $counter=$counter+1;
    }
    if ($counter>1){
      $badguy_y +=30;
      $counter=0;
    }
    
}
sub move_alien {
  my ($step, $app, $t) = @_;
  # calculate where the bad guy will go
  $old_x = $golfball_x;
  $alien_x+=$golfball_step;
  # will stay between x->50,650
  if ($alien_x > 650) {
    $alien_x = 650;
    $alien_step *= -1
  }
  elsif ($alien_x < 50) {
    $alien_x = 50;
    $alien_step *= -1  
  }
  my ($drop);
  # $dropping is global, to avoid trying to drop two bombs at once
  if ($dropping == 0) {
    # for this demo there's c.1/10 chance we'll drop
    # This random number choice is our 'AI'
    $drop = int rand(10);
    if ($drop == 2) {
      # ok, dropping bomb, raise our flag
      $dropping = 1;
      # bomb comes from alien so X,Y based on that
      $golfball_y = $golfball_y + $golfball->h -10;
      $golfball_x = $golfball_x + int($golfball->w/2);
      # sound can't hurt?
      #$bomb_sound = $sound_bomb->play('BombDropping_01.wav');
      # NB NB Now add two new handlers for the extra object - 
      # but keep their handler numbers in global variables
      #$drop_control_move = $app->add_move_handler( \&drop_bomb);
      #$drop_control_show = $app->add_show_handler( \&show_bomb);
    }
  }
}
sub move_rocket {
  my ($step, $app, $t) = @_;
  # my arbitrary distance for a hit
  my $blast_radius = 25;
  $old_badguy_y = $badguy_y;
  # first make sure flag is up (why???)
  if ($firing == 1) {
    $golfball_y = $golfball_y- int ($golfball->h/2)-250;
    $golfball_x = $golfball_x + int ($golfball->w/2)-50;
    if ($badguy_y > -50) {
      # move rocket by whatever amt we wish
      $badguy_y -= 10;
      # call our distance measuring routine
      if (&distance_is($badguy_x, $badguy_y, $badguy_x, $badguy_y) < $blast_radius) {
        print "Bang: Player wins\n";
        $app->stop;
      }      
    }
    if ($badguy_y < -50) {
      # if we get this far the rocket has reached the upper limit 
      # without a hit; remove the handlers using their numbers
      $app->remove_move_handler($fire_control_move);
      $app->remove_show_handler($fire_control_show);
      # stop the sound
      #$fire_sound = $sound_rocket->stop();
      # lower the flag
      $firing = 0;
    }
  }
}

sub distance_is {
  # this isn't a handler; this is just a sub to calc.
  # the distance between an (object, thing).
  # the object can be a projectile, the thing can be a
  # good guy or bad guy
  # Usage: &distance_is (X1, Y1, X2, Y2)
  my ($badguyX1, $badguyY1, $badguyX2, $badguy2) = @_;
  # formula for distance between  two points is:
  # square root of (square(X2 - X1) + square(Y2 - Y1))
  # Using the object as point #1, bad guy as point #2
  my $distance = sqrt (($badguyX2 - $badguyX1)**2 + ($badguyY2 - $badguyY1)**2);
  # I don't mind the decimals for now
  $distance=int($distance);
  # for debuggin
  #print "[$distance]\n";
  return $distance;
}

sub show_alien {
# Draw the alien
  my ($delta, $app) =@_;
  my ($new_badguy_rect, $cover_rect);
    #print "A\n";
  $new_golfball_rect = SDL::Rect->new($golfball_x,$golfball_y,$golfball->w,$golfball->h);  
  $cover_rect = SDL::Rect->new($old_x, $old_y, $golfball->w, $golfball->h);
  SDL::Video::blit_surface($cover, $cover_rect, $application, $cover_rect );      
  SDL::Video::blit_surface ($golfball, $golfballmaster, $application, $new_golfball_rect);
  SDL::Video::update_rects($application, $new_golfball_rect);
  $application->sync();

}    
sub simple_collision {
  # 
  use constant some_arbitrary_value => 100;
  my ($step, $app, $t) = @_;
  # formula for distance between  two points is:
  # square root of (square(X2 - X1) + square(Y2 - Y1))
  # Using Good guy as point #1, bad guy as point #2
  my $distance = sqrt (($badguy_x - $goodguy_x)**2 + ($badguy_y - $goodguy_y)**2);
  # I don't mind the decimals for now
  $distance=int($distance);
  #print "[$distance]\n";
  if ($distance < some_arbitrary_value) {
    print "Bang. You're dead.\n";
    $app->stop;
  }
}      
  
sub show_badguy {
  # Draw the bad guy
  my ($delta, $app) =@_;
  #if (($badguy_x != $old_x) || ($badguy_y != $old_y)) {
    # BadLad has moved so do what needs doing...
    
  #}
  my ($new_badguy_rect, $cover_rect);
    #print "A\n";
  $new_badguy_rect = SDL::Rect->new($badguy_x,$badguy_y,$badguy->w,$badguy->h);  
  $cover_rect = SDL::Rect->new($old_x, $old_y, $badguy->w, $badguy->h);
  SDL::Video::blit_surface($cover, $cover_rect, $application, $cover_rect );      
  SDL::Video::blit_surface ($badguy, $badguymaster, $application, $new_badguy_rect);
  SDL::Video::update_rects($application, $new_badguy_rect);
  $application->sync();  
}

sub quit_event {
  my ($event, $app) = @_;
	if($event->type == SDL_QUIT) {
    $app->stop;
  
}
}
sub key_event {
  my ($event, $app) = @_;

my $key_name = SDL::Events::get_key_name( $event->key_sym );  

my ($old_ship_x, $old_ship_y, $new_ship_rect, $cover_rect);

  if (($key_name eq "x") || ($key_name eq "X") ) {

    $app->stop;

  }

  elsif ($key_name eq "left") {

    $old_ship_x = $goodguy_x;

    $goodguy_x -=$granularity;

    if ($goodguy_x < $goodguy_x_min) {

      $goodguy_x = $goodguy_x_min;

      } # this

  }

  elsif ($goodguy_x < 50) {

    $goodguy_x = 50;

    $goodguy_step *= -1;  

  }

  elsif ($key_name eq "right") {

    $old_ship_x = $goodguy_x;

    $goodguy_x +=$granularity;

    if ($goodguy_x > $goodguy_x_max) {

       $goodguy_x = $goodguy_x_max;

    }

    $goodguy_x+=$goodguy_step;

    if ($goodguy_x > 690){

      $goodguy_x = 690;

      $goodguy_step *= -1;

    }

  }

  $new_ship_rect = SDL::Rect->new($goodguy_x,$goodguy_y,$goodguy->w,$goodguy->h);

  $cover_rect = SDL::Rect->new($old_ship_x, $goodguy_y, $goodguy->w, $goodguy->h);

  SDL::Video::blit_surface($cover, $cover_rect, $application, $cover_rect );    

  SDL::Video::blit_surface ($goodguy, $goodguymaster, $application, $new_ship_rect);

  SDL::Video::update_rects($application, $cover_rect, $new_ship_rect);

    if ($key_name eq "space") {

  # we don't want two shots in the air at once (yet!)

    if ($firing==10) {

      # raise a flag

      $firing = 1;

      # the rocket is fired by the good guy, calculate start point from that

   if ($key_name eq "left") {

     $old_ship_x = $golfball_x;

     $golfball_x -=$granularity;

  }

    elsif ($golfball_x < $golfball_x_min) {

      $golfball_x = $golfball_x_min;

  }

  elsif ($golfball_x < 50) {

    $golfball_x = 50;

    $golfball_step *= -1;  

  }

  elsif ($key_name eq "right") {

    $old_ship_x = $golfball_x;

    $golfball_x +=$granularity;

    if ($golfball_x > $golfball_x_max) {

       $golfball_x = $golfball_x_max;

    }

    $golfball_x+=$golfball_step;

    if ($golfball_x > 690){

      $golfball_x = 690;

      $golfball_step *= -1;

    }

  }

     # maybe sound...?

      #$rocket_sound = $sound_rocket->play('GunFire_01.wav');

      # add handlers, keep their handler numbers for later

      $fire_control_move = $app->add_move_handler( \&move_rocket);

      $fire_control_show = $app->add_show_handler( \&show_rocket);

  }

}

  $new_ship_rect = SDL::Rect->new($golfball_x,$golfball_y,$golfball->w,$golfball->h);

  $cover_rect = SDL::Rect->new($old_golfball_x, $golfball_y, $golfball->w, $golfball->h);

  SDL::Video::blit_surface($cover, $cover_rect, $application, $cover_rect );    

  SDL::Video::blit_surface ($golfball, $golfballmaster, $application, $new_ship_rect);

  SDL::Video::update_rects($application,  $cover_rect, $new_ship_rect);

  # this demo is using 'spaxce' to fire

}

   $new_ship_rect = SDL::Rect->new($goodguy_x,$goodguy_y,$goodguy->w,$goodguy->h);

   $cover_rect = SDL::Rect->new($old_ship_x, $goodguy_y, $goodguy->w, $goodguy->h);

   SDL::Video::blit_surface($cover, $cover_rect, $application, $cover_rect );    

   SDL::Video::blit_surface ($goodguy, $goodguymaster, $application, $new_ship_rect);

   SDL::Video::update_rects($application, $cover_rect, $new_ship_rect);

     if ($key_name eq "space") {

   # we don't want two shots in the air at once (yet!)

     if ($firing==0) {

       # raise a flag

       $firing = 1;

       # the rocket is fired by the good guy, calculate start point from that

    if ($key_name eq "left") {

      $old_ship_x = $golfball_x;

      $golfball_x -=$granularity;

   }

     elsif ($golfball_x < $golfball_x_min) {

       $golfball_x = $golfball_x_min;

   }

   elsif ($golfball_x < 50) {

     $golfball_x = 50;

     $golfball_step *= -1;  

   }

   }

   elsif ($key_name eq "right") {

     $old_ship_x = $golfball_x;

     $golfball_x +=$granularity;

     if ($golfball_x > $golfball_x_max) {

        $golfball_x = $golfball_x_max;

     }

     $golfball_x+=$golfball_step;

     if ($golfball_x > 690){

       $golfball_x = 690;

       $golfball_step *= -1;

     }

   }

       # maybe sound...?

       #$rocket_sound = $sound_rocket->play('GunFire_01.wav');

       # add handlers, keep their handler numbers for later

       $fire_control_move = $app->add_move_handler( \&move_rocket);

       $fire_control_show = $app->add_show_handler( \&show_rocket);

   }

 

   $new_ship_rect = SDL::Rect->new($golfball_x,$golfball_y,$golfball->w,$golfball->h);

   $cover_rect = SDL::Rect->new($old_golfball_x, $golfball_y, $golfball->w, $golfball->h);

   SDL::Video::blit_surface($cover, $cover_rect, $application, $cover_rect );    

   SDL::Video::blit_surface ($golfball, $golfballmaster, $application, $new_ship_rect);

   SDL::Video::update_rects($application,  $cover_rect, $new_ship_rect);

   # this demo is using 'spaxce' to fire




sub show_rocket {
  my ($delta, $app) = @_;
  # do the drawing stuff for the players projectile.
  # This show handler will be added and removed (enabled/disabled)
  # as required by our code.
  $new_ship_rect = SDL::Rect->new($golfball_x,$golfball_y,$golfball->w,$golfball->h);
  $cover_rect = SDL::Rect->new($old_golfball_x, $golfball_y, $golfball->w, $golfball->h);
  SDL::Video::blit_surface($cover, $cover_rect, $application, $cover_rect );    
  SDL::Video::blit_surface ($golfball, $golfballmaster, $application, $old_ship_rect);
  SDL::Video::update_rects($application,  $cover_rect, $new_ship_rect);
  $application->sync();
}

sub mouse_event {
  my ($event, $app) = @_;
  my ($mouse_mask,$mouse_x,$mouse_y)  = @{SDL::Events::get_mouse_state()};
  my ($r, $g, $b, $pixel, $hex); 
  if ($mouse_mask & SDL_BUTTON_LMASK) {
    # left clicked!
    # so get a pixel at the mouse
    $pixel =SDL::Surface::get_pixel($app, $background->w*$mouse_y+$mouse_x);
    # convert it to RGB (5:6:?)
    ($r, $g, $b) = @{SDL::Video::get_RGB($app->format(), $pixel)};
    # show those values
    #print "R[$r] G[$g] B[$b]\n";
    #print "Decimal[$pixel]\n";
    # get a Hexadecimal representation
    #$hex = sprintf("%x",$pixel);
    # and show it
    #print "Hex[$hex]\n";
  }
}

