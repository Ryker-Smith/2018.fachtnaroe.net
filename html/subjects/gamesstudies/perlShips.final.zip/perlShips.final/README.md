perlShips
=========

perl Battleships Game

Author: Dunne, Kevin; Roe, Fachtna
Date: 20140416

Program: perl/SDL implementation of classic battleships game.
Status: MoCR 0
